import psycopg2

conn = psycopg2.connect(
    host="localhost",
    database="store_db",
    user="postgres",
    password="12345"
)

cur = conn.cursor()
cur.execute("SELECT * FROM api_product;")
rows = cur.fetchall()

print(" Все товары из базы данных PostgreSQL:")
for row in rows:
    print(row)

cur.close()
conn.close()