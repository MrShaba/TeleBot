from rest_framework.routers import DefaultRouter
from .views import CategoryViewSet, ProductViewSet

from django.contrib import admin
from django.urls import path, include
from api.views import register_user
from rest_framework.authtoken.views import obtain_auth_token


router = DefaultRouter()
router.register(r'categories', CategoryViewSet)
router.register(r'products', ProductViewSet)

urlpatterns = [
    path('', include(router.urls)),                # категории и продукты
    path('register/', register_user, name='register'),  # регистрация
    path('login/', obtain_auth_token)
]


# router = DefaultRouter()
# router.register(r'categories', CategoryViewSet)
# router.register(r'products', ProductViewSet)

# urlpatterns = [
#     path('admin/', admin.site.urls),
#     path('api/', include('api.urls')),
#     path('api/register/', register_user),
#     path('api/login', obtain_auth_token),
# ]